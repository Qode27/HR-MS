"use client";

import { toast } from "sonner";
import { useApi } from "@/hooks/use-api";
import { PageHeader } from "@/components/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { StatCard } from "@/components/stat-card";
import { useDemoMode } from "@/lib/demo";

export default function ReportsPage() {
  const { data } = useApi<any>("/api/reports/overview", []);
  const isDemo = useDemoMode();
  const presentToday = (data?.kpis?.todayAttendance || []).find((x: any) => x.status === "PRESENT")?._count || 0;
  const absentToday = (data?.kpis?.todayAttendance || []).find((x: any) => x.status === "ABSENT")?._count || 0;

  function exportReport(format: "csv" | "xlsx") {
    if (isDemo) {
      toast.success("Demo mode: action not saved");
      return;
    }
    window.location.href = `/api/reports/export?format=${format}`;
  }

  return (
    <section className="space-y-4">
      <PageHeader
        title="Reports & Analytics"
        subtitle="Attendance, leave, hiring and payroll insights"
        actions={
          <div className="flex gap-2">
            <Button size="sm" variant="outline" onClick={() => exportReport("csv")}>Export CSV</Button>
            <Button size="sm" onClick={() => exportReport("xlsx")}>Export Excel</Button>
          </div>
        }
      />
      <div className="grid gap-4 md:grid-cols-4">
        <StatCard title="Present Today" value={presentToday} />
        <StatCard title="Absent Today" value={absentToday} />
        <StatCard title="Open Jobs" value={data?.kpis?.openJobs || 0} />
        <StatCard title="Interviews Today" value={data?.kpis?.interviewsToday || 0} />
      </div>
      <Card><pre className="overflow-auto text-xs">{JSON.stringify(data, null, 2)}</pre></Card>
    </section>
  );
}
