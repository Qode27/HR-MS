import { NextRequest, NextResponse } from "next/server";
import { jwtVerify } from "jose";
import { COOKIE_NAME, REFRESH_COOKIE_NAME } from "@/lib/constants";

const publicPaths = ["/login", "/forgot-password", "/reset-password", "/careers", "/api/auth/login", "/api/auth/refresh", "/api/auth/reset-password", "/api/health"];
const authBucket = new Map<string, { hits: number; resetAt: number }>();
const encoder = new TextEncoder();
const secret = encoder.encode(process.env.JWT_SECRET || "dev-secret-change-me");
const demoCookieName = "hrms_demo";

async function hasValidSessionToken(accessToken?: string, refreshToken?: string) {
  const verifyToken = async (token: string, expectedType: "access" | "refresh") => {
    try {
      const { payload } = await jwtVerify(token, secret);
      return payload.typ === expectedType;
    } catch {
      return false;
    }
  };

  if (accessToken && (await verifyToken(accessToken, "access"))) return true;
  if (refreshToken && (await verifyToken(refreshToken, "refresh"))) return true;
  return false;
}

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;
  const isDemo = req.nextUrl.searchParams.get("demo") === "true" || req.cookies.get(demoCookieName)?.value === "true" || pathname.startsWith("/hrms/demo");
  if (pathname.startsWith("/_next") || pathname.startsWith("/favicon") || pathname.startsWith("/api/public")) {
    return NextResponse.next();
  }

  const isPublic = publicPaths.some((p) => pathname === p || pathname.startsWith(`${p}/`));
  const accessToken = req.cookies.get(COOKIE_NAME)?.value;
  const refreshToken = req.cookies.get(REFRESH_COOKIE_NAME)?.value;
  const hasAnySessionToken = await hasValidSessionToken(accessToken, refreshToken);

  if (!hasAnySessionToken && !isPublic && !isDemo && !pathname.startsWith("/api/auth/forgot-password") && !pathname.startsWith("/api/auth/logout")) {
    if (pathname.startsWith("/api/")) {
      return NextResponse.json({ success: false, error: { message: "Unauthorized" } }, { status: 401 });
    }
    return NextResponse.redirect(new URL("/login", req.url));
  }

  if ((hasAnySessionToken || isDemo) && (pathname === "/login" || pathname === "/forgot-password" || pathname === "/reset-password")) {
    return NextResponse.redirect(new URL("/dashboard", req.url));
  }

  if (isDemo && pathname.startsWith("/api/")) {
    const res = NextResponse.next();
    res.headers.set("X-Frame-Options", "DENY");
    res.headers.set("X-Content-Type-Options", "nosniff");
    res.headers.set("Referrer-Policy", "strict-origin-when-cross-origin");
    res.headers.set(
      "Content-Security-Policy",
      "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self' data:; connect-src 'self'; frame-ancestors 'none';"
    );
    return res;
  }

  if (pathname.startsWith("/api/auth/login")) {
    const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "unknown";
    const now = Date.now();
    const bucket = authBucket.get(ip);
    if (!bucket || bucket.resetAt <= now) {
      authBucket.set(ip, { hits: 1, resetAt: now + 60_000 });
    } else {
      bucket.hits += 1;
      if (bucket.hits > 20) {
        return NextResponse.json({ success: false, error: { message: "Too many requests" } }, { status: 429 });
      }
    }
  }

  const res = NextResponse.next();
  res.headers.set("X-Frame-Options", "DENY");
  res.headers.set("X-Content-Type-Options", "nosniff");
  res.headers.set("Referrer-Policy", "strict-origin-when-cross-origin");
  res.headers.set(
    "Content-Security-Policy",
    "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self' data:; connect-src 'self'; frame-ancestors 'none';"
  );
  return res;
}

export const config = {
  matcher: ["/:path*"]
};
